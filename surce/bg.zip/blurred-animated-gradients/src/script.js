// @todo Add an SVG grain texture to smooth out the gradient steps.
