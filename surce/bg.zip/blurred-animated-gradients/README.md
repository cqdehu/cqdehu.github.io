# Blurred animated gradients

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jeromche/pen/KKQrGgP](https://codepen.io/Jeromche/pen/KKQrGgP).

An animation that I'm working on for my new website.